package Game;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import java.sql.*;

/*About the Game: 
 *  There are two levels in 1st level the player gets to fight Dragon1, On killing the 1st dragon player moves to level 2.
 *  In level 2 player gets to fight Dragon2 .Dragon2 has flying feature.
 *  When it is flying less life is reduced than the usual.The fly mode switches randomly.
 *  You get maximum 5 attempts to kill each dragon.
 *  There are two guns in each level you'll be asked to select which gun u want.
 *  If you take rest the life of the dragon (if not dead) goes back to 100 and you lose a chance each time.
 *  Score is assigned on the basis of in how many attempts have you killed the dragon.
 *  If you are unable to kill dragon1 in 5 attempts the score goes to 0. 
 *  If you are unable to kill dragon2 in 5 attempts the score goes to the score of level1. 
 *  Multiple players can play this game and their scores will be recorded and will be displayed at the end.
 *  The information of these players gets stored in Game Database player table and the max or top score is displayed (jdbc)*/

public class KillTheDragon {
	//static boolean addPlayer=true;
	static public int gameScore(String player) {
        Dragon d1 = new Dragon("fire",100); 
		Dragon2 d2 = new Dragon2("fire balls",100);
		 Random randomGenerator=new Random();
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Game starts!!!");
	        System.out.println("Level 1");
	        System.out.println("select gun 1 or 2");      
	        int gun=sc.nextInt();
	        System.out.println(gun+" Selected");
	        int score=10;                                  // level1 score
	        int score2=10;                                 // level2 score
	       try {                                                // exception handling
	        for(int i=1;i<=5;i++)
	        { 
	        	if(d1.getLife()==0) {
	     	   break;
	        }
	        	score=score-1;
	        	int letsRest=0;
	          if(i!=1) {
	            System.out.println("!do you want to rest so enter 1 or else to shoot 0");
	            letsRest=sc.nextInt();
	            if(letsRest==1) {
	        	  d1.rest();
	        	  continue;
	           }
	          }
	          System.out.println("Shooting!!");
	          if(letsRest==0) {
	          if(gun==1) {
	        	  d1.damageByGun1();
	          }
	          if(gun==2) {
	        	  d1.damageByGun2();
	          }
	          else if(gun!=1 & gun!=2) {
	        	 throw new ArithmeticException(" gun "+gun+" not found, please restart the game and select gun 1 or 2"); 
	        	                                              //   Exception throwing
	          }
	         }
	         
	        else if(letsRest!=0 || letsRest!=1) {
          	  throw new ArithmeticException("invalide input");
	          }
             }
	       
	         if(d1.getLife()==0) {
	        	
	        	System.out.println("Level 2 get ready!!");
	        	 System.out.println("select gun 1 or 2");
	             int gun1=sc.nextInt();
	             System.out.println(gun1+" Selected");
	             for(int i=1;i<=5;i++)
	             { 
	            	 if(d2.getLife()==0) {
	              	   break;
	             }
	            	 score2=score2-1;
	            	 int randomInt= randomGenerator.nextInt(2) ; // randomly invoking fly feature 
	            	 //System.out.println(randomInt+"*&*&");
	          		if(randomInt==1) {
	          		    d2.setFly(true);
	          	    }
	          		if(randomInt==0) {
	          			d2.setFly(false);
	          		}	
	          		int letsRest=0;
	               if(i!=1) {
	                 System.out.println("!do you want to rest so enter 1 or else to shoot 0");
	                 letsRest=sc.nextInt();
	                 if(letsRest==1) {
	             	  d2.rest();
	             	  continue;
	                }
	                 
	               }
	               System.out.println("Shooting!!");
	               if(letsRest==0) {
	                	 
	                   
	               if(gun1==1) {
	             	  d2.damageByGun1();
	               }
	               if(gun1==2) {
	             	  d2.damageByGun2();
	               }
	               
	               else if(gun1!=1 & gun1!=2) {
	             	 throw new ArithmeticException("gun "+ gun1+" not found, please restart the game and select gun 1 or 2"); 
                                                              //     Exception throwing
	               } 
	              }
	               else if(letsRest!=0 || letsRest!=1) {
	            	  throw new ArithmeticException("invalide input");
	               }
	        }
	             if(d2.getLife()!=0) {
	            	score2=0; 
	            	System.out.println("Game Over :( "); 
	             }
	       
		}
	        else {
	        	System.out.println("Game Over :( ");
	        	score=0;
	        }
	       }
	       catch(ArithmeticException e) {                  // exception handling
	    	   System.out.println(e);
	       }
		return (score+score2);
	}

	public static void main(String[] args) throws Exception {           // exception handling
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/game";
		String uname="root";
		String pass="mysql";
		String query="select score from player where score=(select max(score) from player)"; // query
		
		Class.forName("com.mysql.cj.jdbc.Driver"); // load and register the driver 
		Connection con= DriverManager.getConnection(url,uname,pass); // Create connection
		Statement st=con.createStatement();   // Create Statement 
		String query2="insert into player values ( ?,? )";   // query
		PreparedStatement st1= con.prepareStatement(query2);
		ResultSet rs = st.executeQuery(query);      // execute query and process result
		rs.next();
		
		int max_score = rs.getInt("score");
		System.out.println("Top score : "+ max_score);
		
		HashMap<String, Integer> scoreBoard=new HashMap<>();        // collections
		boolean addPlayer=true;
		Scanner sc=new Scanner(System.in);
		
		while(addPlayer) {
			
			System.out.println("To add Player enter yes or else no");
			String adding=sc.nextLine();
			if(adding.equalsIgnoreCase("yes")) {
				addPlayer=true;
				System.out.println("Enter Player's name");
				String playerName=sc.nextLine();
				int new_score=gameScore(playerName);
				scoreBoard.put(playerName,new_score );
				st1.setString(1, playerName);  
				st1.setInt(2, new_score);
				int a=st1.executeUpdate();   // execute query and process result
				
		
			}
			else if(adding.equalsIgnoreCase("no")) {
				addPlayer=false;
				System.out.println("Player not added ");
				break;
			}
			else {
				System.out.println("Invalid input player not added");
			}
			System.out.println();
			Thread.sleep(3000);     //                   Thread sleep concept
		}
		for(HashMap.Entry m:scoreBoard.entrySet()) {
			System.out.println(m.getKey()+"'s score is "+m.getValue()); //    printing the scores of each player
		}
		
		 rs = st.executeQuery(query);
		 rs.next();
		max_score = rs.getInt("score");
		System.out.println("Top score : "+ max_score);
		
		st.close();    // close statement
		st1.close();
		con.close();   // close connection
   }
}
