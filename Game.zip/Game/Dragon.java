package Game;
import Game.MonsterStructure;

public class Dragon implements MonsterStructure{ 
	 private String power;    //concept of encapsulation
	    private int life;

	    public Dragon(String power, int life) { //concept of encapsulation
	 
	        this.power = power;      
	        if(life < 0 || life > 100){
	            this.life = 100;
	        }else this.life = life;
	    }
	   
	    public void damageByGun1(){   //over-riding polymorphism
	      
			   this.life -= 20;
			
	        if(this.life <=0){
	            this.life = 0;
	        }
	        System.out.println("Got hit by gun 1. Dragon's life is reduced by 20" +
	                ". life is "+ this.life);
	        if(this.life == 0){
	            System.out.println(" dragon is dead");
	        }
		   
		  
	    }
	    public void damageByGun2(){   //over-riding polymorphism
	        this.life -= 40;
			
	        if(this.life <=0){
	            this.life = 0;
	        }
	        System.out.println("Got hit by gun 2. life is reduced by 40" +
	                ". life is "+ this.life);
	        if(this.life == 0){
	            System.out.println("dragon is dead");
	        }
			
	    }

	    public void rest(){   //over-riding polymorphism
			
	        if(this.life <= 0 ) System.out.println("Dragon is dead. You win");
	        else{
	            this.life = 100;
	            System.out.println("life is "+this.life);
	        }
	    }

	    public String getPower() { //concept of encapsulation
	        return power;
	    }

	    public void setPower(String power) { //concept of encapsulation
	        this.power = power;
	    }

	    public int getLife() { //concept of encapsulation
	        return life;
	    }

	    public void setLife(int life) { //concept of encapsulation
	        this.life = life;
	    }

}
