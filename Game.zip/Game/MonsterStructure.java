package Game;

public interface MonsterStructure {
	void damageByGun1();
	void damageByGun2();
	void rest();
}
