package Game;
//import Game.Dragon;

public class Dragon2 extends Dragon{
    private int life;
    private boolean fly;

    public Dragon2(String power, int life, boolean fly) {
        super(power, life);
        this.life = life;
        this.fly = fly;
    }

    
    public void damageByGun1() {
        try{
			if(fly){
             
			    this.life -= 20;
			
		if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
		}
            if(this.life ==0) 
            System.out.println("Dragon is flying. Got hit by gun 1. Dragon's life is reduced by 20." +
                    "life is "+ this.life);
        } if(!fly){
           
			   this.life -= 30;
			if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
		}
            if(this.life ==0) this.life = 0;
            System.out.println("Dragon is on the ground. Got hit by gun 1. Life is reduced by 30." +
                    "life is "+ this.life);
        }
        if(this.life == 0){
            System.out.println("Dragon is dead");
		 }
		
		
        }
		 catch(ArithmeticException e){
		   e.printStackTrace();
	   }
    }

    
    public void damageByGun2() {
       try{
		   if(fly){
			   
            this.life -= 40;
			if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
			   }
            if(this.life ==0) this.life = 0;
            System.out.println("Dragon is flying. Got hit by gun 2. Life is reduced by 40." +
                    "life is "+ this.life);
        } if(!fly){
            this.life -= 50;
			if(this.life <0){
			throw new ArithmeticException("Dragon  is dead already");
			   }
            if(this.life ==0) this.life = 0;
            System.out.println("Dragon is on the ground. Got hit by gun 2. Life is reduced by 50." +
                    "life is "+ this.life);
        }
        if(this.life == 0){
            System.out.println("Dragon is dead");
        }
	   }
	   catch(ArithmeticException e){
		   e.printStackTrace();
	   }
	   
	   }
    

   
    public void rest() {
        super.rest();
    }
}