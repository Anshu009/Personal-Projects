package com.anshu.servlet;
import com.anshu.model.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Score
 */
@WebServlet("/Score")
public class Score extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Score() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		String ans=request.getParameter("ans");
		PrintWriter out= response.getWriter();
		HttpSession session=request.getSession();
		int nmbr=(int) session.getAttribute("nmbr");
		int count=(int) session.getAttribute("count");
		//Map<Integer,Quizing> mp=(Map<Integer, Quizing>) session.getAttribute("map");
		List<String> al=(List<String>) session.getAttribute("al");
		List<Quizing> qstn=(List<Quizing>) session.getAttribute("qstn");
		al.add(" ");
		if(nmbr<qstn.size()-1){
			al.set(nmbr, ans);
			session.setAttribute("al", al);
			response.sendRedirect("Next");
			//response.sendRedirect("Quiz");
		}
		else if(nmbr==(qstn.size()-1)){
			al.set(nmbr, ans);
			session.setAttribute("al", al);
			for(int i=0;i<=qstn.size()-1;i++){
				
				if(qstn.get(i).getAns().equals(al.get(i))){
					count+=1;
					session.setAttribute("count", count);
					
				}
				
			}
			out.write("<h3>Your Score is "+count+"</h3>");
			session.invalidate();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
