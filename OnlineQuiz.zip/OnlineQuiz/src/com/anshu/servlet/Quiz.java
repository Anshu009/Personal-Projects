package com.anshu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.*; 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.anshu.dao.QuizDaoImp;
import com.anshu.model.Quizing;

/**
 * Servlet implementation class Quiz
 */
@WebServlet("/Quiz")
public class Quiz extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Quiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		List<Quizing> qstn;
		try{
		qstn=new QuizDaoImp().getAllQuestions();
		
//		Map<Integer, Quizing> map= new HashMap<>();
//		map.put(1, new Quizing(1,"What is Java?","A type of food", "A programming language", "A car", "A person's name","b"));
//		map.put(2, new Quizing(2,"Who invented Java Programming?","Guido van Rossum", "James Gosling", "Dennis Ritchie", "Bjarne Stroustrup","b"));
//		map.put(3, new Quizing(3,"Which one of the following is not a Java feature?"," Object-oriented", "Use of pointers", "Portable", "Dynamic and Extensible","b"));
//		map.put(4, new Quizing(4,"Which of these cannot be used for a variable name in Java?"," identifier & keyword", "identifier", " keyword", "none of the mentioned","c"));
//		map.put(5, new Quizing(5,"Which component is used to compile, debug and execute the java programs"," JRE", " JIT", " JDK", "JVM","c"));
		
		
//		List<String> al= new ArrayList<>();
		
		HttpSession session= request.getSession();
    //  session.setAttribute("map",map );
		session.setAttribute("qstn", qstn);
	//	session.setAttribute("al",al );
		int nmbr=(int) session.getAttribute("nmbr");
		PrintWriter out= response.getWriter();
		
		if(nmbr<qstn.size()-1){
		request.getRequestDispatcher("firstLink.html").include(request, response);
   	out.print("<form action='Score'><table ><th><h1>"+qstn.get(nmbr).getQstn()+"</h1></th>");
   	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+qstn.get(nmbr).getA()+"</h2><br></td></tr>");
   	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+qstn.get(nmbr).getB()+"</h2><br></td></tr>");
   	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+qstn.get(nmbr).getC()+"</h2><br></td></tr></table>");
   	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+qstn.get(nmbr).getD()+"</h2><br></td></tr></table>");
   	out.print("<tr><td><input type='submit' value='Save Response'></td></tr></table></form>");
		}
//		 if(nmbr==1){
//			    request.getRequestDispatcher("firstLink.html").include(request, response);
//	        	out.print("<form action='Score'><table ><th><h1>"+map.get(1).getQstn()+"</h1></th>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+map.get(1).getA()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+map.get(1).getB()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+map.get(1).getC()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+map.get(1).getD()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='submit' value='Save Response'></td></tr></table></form>");
//	        	  
//	        }
//		 if(nmbr==2){
//			    request.getRequestDispatcher("link.html").include(request, response);
//	        	out.print("<form action='Score'><table ><th><h1>"+map.get(2).getQstn()+"</h1></th>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+map.get(2).getA()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+map.get(2).getB()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+map.get(2).getC()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+map.get(2).getD()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='submit' value='Save Response>'</td></tr></table></form>");
//	        	  
//	        }
//		 if(nmbr==3){
//			    request.getRequestDispatcher("link.html").include(request, response);
//	        	out.print("<form action='Score'><table ><th><h1>"+map.get(3).getQstn()+"</h1></th>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+map.get(3).getA()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+map.get(3).getB()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+map.get(3).getC()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+map.get(3).getD()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='submit'value='Save Response'></td></tr></table></form>");
//	        	  
//	        }
//		 if(nmbr==4){
//			    request.getRequestDispatcher("link.html").include(request, response);
//	        	out.print("<form action='Score'><table ><th><h1>"+map.get(4).getQstn()+"</h1></th>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+map.get(4).getA()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+map.get(4).getB()+"</h2><br></td></tr>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+map.get(4).getC()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+map.get(4).getD()+"</h2><br></td></tr></table>");
//	        	out.print("<tr><td><input type='submit' value='Save Response'></td></tr></table></form>");
//	        	  
//	        }
   	     else if(nmbr==qstn.size()-1){
			    request.getRequestDispatcher("lastLink.html").include(request, response);
	        	out.print("<form action='Score'><table ><th><h1>"+qstn.get(nmbr).getQstn()+"</h1></th>");
	        	out.print("<tr><td><input type='radio' name='ans' value='a'><h2>"+qstn.get(nmbr).getA()+"</h2><br></td></tr>");
	        	out.print("<tr><td><input type='radio' name='ans' value='b'><h2>"+qstn.get(nmbr).getB()+"</h2><br></td></tr>");
	        	out.print("<tr><td><input type='radio' name='ans' value='c'><h2>"+qstn.get(nmbr).getC()+"</h2><br></td></tr></table>");
	        	out.print("<tr><td><input type='radio' name='ans' value='d'><h2>"+qstn.get(nmbr).getD()+"</h2><br></td></tr></table>");
	        	out.print("<tr><td><input type='submit' value='Submit Test'></td></tr></table></form>");
	        	  
	        }
		}catch(Exception SQLException){}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
