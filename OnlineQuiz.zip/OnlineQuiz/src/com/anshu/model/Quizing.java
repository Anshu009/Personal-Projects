package com.anshu.model;

public class Quizing {
	
	private int qstnId;
	private String qstn;
	private String a;
	private String b;
	private String c;
	private String d;
	private String ans;
	public Quizing() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getQstnId() {
		return qstnId;
	}
	public void setQstnId(int qstnId) {
		this.qstnId = qstnId;
	}
	public String getQstn() {
		return qstn;
	}
	public void setQstn(String qstn) {
		this.qstn = qstn;
	}
	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getD() {
		return d;
	}
	public void setD(String d) {
		this.d = d;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public Quizing(int qstnId, String qstn, String a, String b, String c, String d, String ans) {
		super();
		this.qstnId = qstnId;
		this.qstn = qstn;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.ans = ans;
	}
	
}
