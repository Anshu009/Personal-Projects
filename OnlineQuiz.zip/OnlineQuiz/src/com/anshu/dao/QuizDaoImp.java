package com.anshu.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.List;


import com.anshu.model.Quizing;

public class QuizDaoImp implements QuizDao {

	@Override
	public List<Quizing> getAllQuestions() {
		List<Quizing> qstn=new ArrayList<Quizing>();
		Connection conn= ConnectionMaster.getConnection();
		try{
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery("select * from Quizing");
		while(rs.next()){
			qstn.add(new Quizing(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)));
		}
		}catch(Exception SQLException){}
		//qstn.stream().forEach(e->System.out.println(e));
		return qstn;
	}

}
