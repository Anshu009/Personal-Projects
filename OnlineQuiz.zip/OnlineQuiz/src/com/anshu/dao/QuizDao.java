package com.anshu.dao;

import java.util.List;

import com.anshu.model.Quizing;

public interface QuizDao {
   public List<Quizing> getAllQuestions(); 
}
